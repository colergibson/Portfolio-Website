# Assignment 5
# This program uses a GUI to prompt the user for an input file and search term,
# and then calculates and displays the number of occurrences (frequency) of the term in the file.

import tkinter
import tkinter.filedialog
import string


class TermFrequencyGUI:
    def __init__(self):
        # Create the main window
        self.main_window = tkinter.Tk()
        self.main_window.title("Term Frequency")
        self.main_window.configure(background='#F4FFF9')
        self.main_window.geometry('350x130')

        # Create frames
        self.file_name_frame = tkinter.Frame(self.main_window)
        self.search_term_frame = tkinter.Frame(self.main_window)
        self.term_frequency_frame = tkinter.Frame(self.main_window)

        # Create the widgets for the filename frame, and pack them

        # Select File Button
        self.select_file_button = tkinter.Button(self.file_name_frame, text='Select a file', command=self.select_file)
        self.select_file_button.configure(width=10, bg='#423986', fg='white', font=("Helvetica", 8), anchor=tkinter.constants.CENTER)

        # File Name Label
        self.file_name = tkinter.StringVar()
        self.file_name_label = tkinter.Label(self.file_name_frame, textvariable=self.file_name)
        self.file_name_label.configure(width=40, bg='#F4FFF9', fg='#24817E', font=("Helvetica", 8))

        self.select_file_button.pack(padx=10, pady=10, side='left')
        self.file_name_label.pack(padx=10, pady=10, side='left')

        # Create the widgets for the search term frame, and pack them

        # Search Term Label
        self.search_term_label = tkinter.Label(self.search_term_frame, text='Enter a search term:')
        self.search_term_label.configure(width=20, bg='#F4FFF9', fg='black', font=("Helvetica", 8), anchor=tkinter.constants.CENTER)

        # Search Term Entry
        self.search_term_entry = tkinter.Entry(self.search_term_frame)
        self.search_term_entry.configure(width=40, font=("Helvetica", 8))

        self.search_term_label.pack(padx=10, pady=10, side='left')
        self.search_term_entry.pack(padx=(5, 35), pady=10, side='right')

        # Create the widgets for the term frequency frame, and pack them

        # Term Frequency Button
        self.term_frequency_button = tkinter.Button(self.term_frequency_frame, text='Calculate frequency ', command=self.calculate_frequency)
        self.term_frequency_button.configure(width=18, bg='#423986', fg='white', font=("Helvetica", 8), anchor=tkinter.constants.CENTER)

        # Term Frequency Label
        self.term_frequency = tkinter.StringVar()
        self.term_frequency_label = tkinter.Label(self.term_frequency_frame, textvariable=self.term_frequency)  # Label to display frequency value
        self.term_frequency_label.configure(width=40, bg='#F4FFF9', fg='#24817E', font=("Helvetica", 8))

        self.term_frequency_button.pack(padx=(35, 5), pady=10, side='left')
        self.term_frequency_label.pack(padx=(10, 5), pady=10, side='left')

        # Pack the frames
        self.file_name_frame.pack()
        self.search_term_frame.pack()
        self.term_frequency_frame.pack()

        # Enter the tkinter main loop
        tkinter.mainloop()

    # When user clicks 'Select a file' button, this function is called to open a file dialog and obtain the file name
    def select_file(self):
        # Set options for this file dialog
        self.file_opts = options = {}
        options['defaultextension'] = '.txt'
        options['filetypes'] = [('text files', '.txt')]
        options['title'] = 'File Selector'

        # The askopenfilename function opens the file dialog and returns the name of the file the user selected
        filename = tkinter.filedialog.askopenfilename(**self.file_opts)
        # Remove directory path information
        index = filename.rfind('/')
        if index >= 0:
            filename = filename[index+1:]
        # Set the value of the file name if one was selected, else display a message
        if filename:
            self.file_name.set(filename)
        else:
            self.file_name.set('No file was selected')

    # When user clicks 'Calculate frequency' button, this function is called to open the file
    # and count the number of occurrences of the search term
    def calculate_frequency(self):
        # These statements get the name of the file to open, and the user-specified search term
        filename = self.file_name.get()
        searchterm = self.search_term_entry.get()
        term_frequency = 0
        # Read each line in the file, remove the punctuation, and look for the search term.
        # Use a counter to keep track of how many times you found the search term in the file.
        if filename:
            if searchterm:

                try:
                    infile = open(filename, 'r')

                    searchterm = searchterm.lower()
                    for line in infile:
                        line = self.remove_punctuation(line_of_text=line)
                        for word in line:
                            if searchterm == word:
                                term_frequency += 1
                    infile.close()

                    if term_frequency > 0:
                        if term_frequency == 1:
                            self.term_frequency.set("'" + searchterm + "'" + " occurs once")
                        else:
                            self.term_frequency.set("'" + searchterm + "'" + " occurs " + str(term_frequency) + " times")
                    else:
                        self.term_frequency.set("'" + searchterm + "'" + " not found")  # If search term isn't found

                except FileNotFoundError:
                    print('File does not exist.')
                except OSError as err:
                    print('OS Error occurred:', err)
                except Exception as err:
                    print('Error occurred:', err)

            else:
                self.term_frequency.set("No search term was entered")  # If no search term is entered
        else:
            self.file_name.set("No file was selected")  # If no file was selected

    def remove_punctuation(self, line_of_text):
        clean_words = []
        line_of_text = line_of_text.rstrip()
        words = line_of_text.split()
        for word in words:
            clean_words.append(word.strip(string.punctuation).lower())
        return clean_words

termFreq = TermFrequencyGUI()
