import urllib.request
import urllib.error
import xml.etree.ElementTree as ET
import webbrowser
import re


def main():
    xml_parse()
    html_output()


def xml_parse():
    try:
        # Pulling RSS feed
        feed_name = 'https://www.cnet.com/rss/most-popular-products/'
        feed = urllib.request.urlopen(feed_name)
        tree = ET.parse(feed)

        # Opening xml file for writing
        xml_outfile = open('cnet_popular_products.xml', 'w')
        xml_outfile.write('<?xml version="1.0"?>\n')
        xml_outfile.write('<root>\n')
        xml_outfile.write('<channel>\n')

        for item in tree.findall('channel'):
            site_title = item.findtext('title')
            xml_outfile.write('\t<title>' + site_title + '</title>\n')

        for item in tree.findall('channel/item'):  # findall is similar to iterfind
            title = item.findtext('title')
            link = item.findtext('link')
            date = item.findtext('pubDate')

            # Removing Time and Time zone
            timepat = re.compile(r'\d{2}[:]\d{2}[:]\d{2}[ ][+]\d{4}')
            time = timepat.findall(date)
            date = date.replace(time[0], '')
            date = date.strip()

            desc = item.findtext('description')

            # Special processing to handle the media:thumbnail element (see Media RSS Spec)
            thumb = item.find('{http://search.yahoo.com/mrss/}thumbnail')  # use media namespace to find thumbnail
            image = thumb.attrib.get('url')  # use get function to get the value of the 'url'

            xml_outfile.write('\t<item>\n')
            xml_outfile.write('\t\t<title>' + title + '</title>\n')
            xml_outfile.write('\t\t<link>' + link + '</link>\n')
            xml_outfile.write('\t\t<pubDate>' + date + '</pubDate>\n')
            xml_outfile.write('\t\t<description>' + desc + '</description>\n')
            xml_outfile.write('\t\t<image>' + image + '</image>\n')
            xml_outfile.write('\t</item>\n')

        xml_outfile.write('</channel>\n')
        xml_outfile.write('</root>')
        xml_outfile.close()

    except urllib.error.HTTPError as err:
        print('Error: unable to access URL:', err)
    except ET.ParseError as err:
        print('Error: Unable to parse input file:', err)
    except FileNotFoundError as err:
        print('Error: Unable to find file: ', err)
    except OSError as err:
        print('Error: Unable to access file: ', err)
    except Exception as err:
        print('An error occurred: ', err)


def html_output():

    try:
        # Open output file to write HTML to
        html_outfile = open('xmlfeed.html', 'w')
        html_outfile.write('<!DOCTYPE html>\n')
        html_outfile.write('<html>\n')

        # Create header information
        html_outfile.write('<head>\n')

        # Finding site title
        tree = ET.parse('cnet_popular_products.xml')
        for item in tree.findall('channel'):
            site_title = item.findtext('title')
            html_outfile.write('\t<title>' + site_title + '</title>\n')
            html_outfile.write('\t<link href="style.css" rel="stylesheet" />\n')
            html_outfile.write('</head>\n')
            html_outfile.write('<body>\n')
            html_outfile.write('<h1>' + site_title + '</h1>\n')

        # Extract and output tags of interest
        for item in tree.findall('channel/item'):  # findall is similar to iterfind
            title = item.findtext('title')
            link = item.findtext('link')
            date = item.findtext('pubDate')
            desc = item.findtext('description')
            image_url = item.findtext('image')

            # Format the title, link, date, desc, and image as HTML and write to output file
            html_outfile.write('<div>\n\t<section id="image">\n')
            html_outfile.write('\t\t<a href="' + link + '">' + '<img src="' + image_url)
            html_outfile.write('">\n</a></section>')

            html_outfile.write('\t<section id="desc">\n')
            html_outfile.write('\t<h3><a href=' + link + "'>" + title)
            html_outfile.write('</a></h3>\n')

            html_outfile.write('\t\t<p><em>' + date + '</em></p>\n')
            html_outfile.write('\t\t<p>' + desc + '</p>\n')
            html_outfile.write('\t</section>\n</div>\n')

        html_outfile.write('</body>\n')
        html_outfile.write('</html>')
        html_outfile.close()
        webbrowser.open_new_tab(html_outfile.name)

    except ET.ParseError as err:
        print('Error: Unable to parse input file:', err)
    except FileNotFoundError as err:
        print('Error: Unable to find file: ', err)
    except OSError as err:
        print('Error: Unable to access file: ', err)
    except webbrowser.Error as err:
        print('Error: Unable to open browser', err)
    except Exception as err:
        print('An error occurred: ', err)

main()
