# This program reads an input file, normalizes the contents by
# using stopwords, lowercasing, and punctuation removal, and writes the normalized content to an output file.
# The keyword density is calculated using the stopword count and total word count for the input file.
import string   # this is required to reference the string.punctuation constant in the remove_punctuation function


def main():
    # Call this function to create a list of stopwords from the stopwords.txt file
    stopwords = create_stopword_list()
    word_count = 0
    stopword_count = 0
    index = 0

    try:
        # Open the input file, LearnToCode_LearnToThink.txt for reading
        infile = open('LearnToCode_LearnToThink.txt', 'r')

        # Open the output file, NormalizedText.txt for writing
        outfile = open('NormalizedText.txt', 'w')

        text = infile.readlines()
        infile.close()

        while index < len(text):  # Calling function to remove punctuation
            line = (remove_punctuation(line_of_text=text[index]))
            for word in line:
                word_count += 1
                if word in stopwords:  # Checking to see if word is a stop word
                    stopword_count += 1
                else:
                    outfile.write(word)  # Writing non-stop word to file
                    outfile.write(' ')
            outfile.write('\n')
            index += 1

        outfile.close()

        print("Word Count:", word_count)
        print("Stopword Count:", stopword_count)
        print("Keyword Density: ", format((1-(stopword_count / word_count)) * 100, '.2f'), "%", sep="")

    except FileNotFoundError:
        print('File does not exist.')
    except OSError as err:
        print('OS Error occurred:', err)
    except Exception as err:
        print('Error occurred:', err)


# Function to create a list from a text file containing stopwords

def create_stopword_list():
    clean_stopwords = []
    try:
        stoplist = open('stopwords.txt', 'r', encoding='utf8')
        stopwords = stoplist.readlines()
        for word in stopwords:
            clean_stopwords.append(word.rstrip())
        stoplist.close()
    except FileNotFoundError:
        print('Stopwords file does not exist.')
    except OSError as err:
        print('OS Error occurred:', err)
    except Exception as err:
        print('Error occurred:', err)

    return clean_stopwords


# Function to remove punctuation and to lowercase words in a line of text
# Do NOT modify this function
def remove_punctuation(line_of_text):
    clean_words = []                        # create an empty list to contain 'cleaned' words
    line_of_text = line_of_text.rstrip()    # remove whitespace (newline) characters
    words = line_of_text.split()            # create a list of words from the line of text

    # for each word, remove punctuation, convert to lower case, and add to the list
    for word in words:
        clean_words.append(word.strip(string.punctuation).lower())

    return clean_words


main()
